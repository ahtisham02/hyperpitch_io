import React from "react";
import { useState } from "react";
import { Outlet } from "react-router-dom";
import Navbar from "../ui-components/AdminPage/Common/Navbar";
import Sidebar from "../ui-components/AdminPage/Common/Sidebar";
import Footer from "../ui-components/AdminPage/Common/Footer";

const Layout = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  return (
    <div className="relative md:h-screen md:overflow-hidden md:flex font-heading bg-slate-50 text-slate-800">
      <Sidebar isSidebarOpen={isSidebarOpen} toggleSidebar={toggleSidebar} />

      <div className="flex-1 flex flex-col lg:overflow-hidden">
        <Navbar toggleSidebar={toggleSidebar} />

        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-white">
          <Outlet />
        </main>

        <Footer />
      </div>

      {isSidebarOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-30 md:hidden"
          onClick={toggleSidebar}
        ></div>
      )}
    </div>
  );
};

export default Layout;
