import React from 'react'
import Header from '../../../ui-components/LandingPage/Home/Header';

export default function HomePage() {
   return (
       <div className="flex-grow overflow-hidden">
         <Header />
       </div>
   );
}
