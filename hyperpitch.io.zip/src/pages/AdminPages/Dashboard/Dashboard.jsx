import React from 'react'
import Header from '../../../ui-components/AdminPage/Dashboard/Header';

export default function AboutPage() {
   return (
       <div className="flex-grow">
         <Header />
       </div>
   );
}
