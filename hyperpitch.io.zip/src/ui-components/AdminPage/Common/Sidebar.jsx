import React from "react";
import { NavLink, Link } from "react-router-dom";
import {
  Feather,
  LayoutGrid,
  PieChart,
  User,
  Settings2,
  LogOut,
  X,
} from "lucide-react";

const Sidebar = ({ isSidebarOpen, toggleSidebar }) => {
  const accentColor = "sky"; // You can change this: e.g., "emerald", "rose", "violet"
  const siteName = "Hyperpitch.io";

  const navItems = [
    { name: "Dashboard", path: "/dashboard", icon: LayoutGrid },
    { name: "Analytics", path: "/reports", icon: PieChart },
  ];

  const userProfileItems = [
    { name: "My Profile", path: "/profile", icon: User },
  ];

  const baseLinkClass = `flex items-center space-x-3.5 py-2.5 px-3.5 text-sm rounded-lg group transition-all duration-200 ease-in-out`;
  const activeLinkClass = `bg-slate-700/50 text-slate-100 font-medium`;
  const defaultLinkClass = `text-slate-400 hover:text-slate-100 hover:bg-slate-700/50`;

  const handleLinkClick = () => {
    if (window.innerWidth < 768 && isSidebarOpen) {
      toggleSidebar();
    }
  };

  const NavIcon = ({ icon: Icon, isActive }) => {
    const commonIconContainerClass = "flex items-center justify-center w-8 h-8 rounded-lg";
    if (isActive) {
      return (
        <span className={`${commonIconContainerClass} bg-${accentColor}-500 shadow-md shadow-${accentColor}-500/30`}>
          <Icon size={18} className="text-white" strokeWidth={2.25} />
        </span>
      );
    }
    return (
      <span className={`${commonIconContainerClass} bg-slate-700/30 group-hover:bg-slate-600/50`}>
        <Icon
          size={20}
          className={`text-slate-400 group-hover:text-${accentColor}-400 transition-colors duration-200`}
          strokeWidth={1.75}
        />
      </span>
    );
  };
  
  const LogoutIcon = () => {
    const commonIconContainerClass = "flex items-center justify-center w-8 h-8 rounded-lg";
     return (
      <span className={`${commonIconContainerClass} bg-rose-500/10 group-hover:bg-rose-500/20`}>
        <LogOut 
            size={19} 
            className="text-rose-500 group-hover:text-rose-400 transition-colors" 
            strokeWidth={1.9}
        />
      </span>
     )
  }

  return (
    <aside
      className={`fixed inset-y-0 left-0 z-40 flex flex-col transform transition-transform duration-300 ease-in-out
                 w-72 bg-slate-800 border-r border-slate-700/60 text-slate-300
                 ${isSidebarOpen ? "translate-x-0 shadow-2xl" : "-translate-x-full"} 
                 md:translate-x-0 md:shadow-xl md:relative md:z-auto md:rounded-r-2xl`}
    >
      {/* === Updated Header Section === */}
      <div 
        className={`flex items-center justify-between p-5 bg-slate-900/70 border-b border-slate-700/50`}
        // bg-slate-900/70 gives a slightly darker, semi-transparent look over slate-800
        // You could also use a solid like bg-slate-900 or bg-black/20
      >
        <Link 
          to="/" 
          onClick={handleLinkClick} 
          className="flex items-center space-x-3 group" // Icon and Name side-by-side
        >
          <div 
            className={`p-3 rounded-xl bg-gradient-to-br from-${accentColor}-500 to-${accentColor}-600 shadow-lg shadow-${accentColor}-500/40`}
          >
            <Feather size={26} className="text-white" strokeWidth={1.75} /> 
          </div>
          <span 
            className={`text-xl font-bold text-slate-100 group-hover:text-${accentColor}-300 transition-colors duration-200 tracking-tight`}
          >
            {siteName}
          </span>
        </Link>
        {/* Mobile close button, now part of the flex layout */}
        {isSidebarOpen && ( 
          <button
            onClick={toggleSidebar}
            className="md:hidden p-1.5 rounded-lg text-slate-400 hover:bg-slate-700 active:bg-slate-600 transition-colors"
            aria-label="Close sidebar"
          >
            <X size={22} /> 
          </button>
        )}
      </div>
      {/* === End of Updated Header Section === */}

      <nav className="flex-1 px-4 py-5 space-y-1.5 overflow-y-auto">
        {navItems.map((item) => (
          <NavLink
            key={item.name}
            to={item.path}
            onClick={handleLinkClick}
            className={({ isActive }) =>
              `${baseLinkClass} ${isActive ? activeLinkClass : defaultLinkClass}`
            }
          >
            {({ isActive }) => (
              <>
                <NavIcon icon={item.icon} isActive={isActive} />
                <span>{item.name}</span>
              </>
            )}
          </NavLink>
        ))}
      </nav>

      <div className="px-4 py-5 mt-auto border-t border-slate-700/60 space-y-1.5">
         {userProfileItems.map((item) => (
          <NavLink
            key={item.name}
            to={item.path}
            onClick={handleLinkClick}
            className={({ isActive }) =>
              `${baseLinkClass} ${isActive ? activeLinkClass : defaultLinkClass}`
            }
          >
             {({ isActive }) => (
              <>
                <NavIcon icon={item.icon} isActive={isActive} />
                <span>{item.name}</span>
              </>
            )}
          </NavLink>
        ))}
        <button
          onClick={() => { console.log("Signing out..."); handleLinkClick(); }}
          className={`${baseLinkClass} ${defaultLinkClass} w-full !text-rose-500 hover:!text-rose-400 hover:!bg-rose-500/10 group`}
        >
          <LogoutIcon />
          <span>Sign Out</span>
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;