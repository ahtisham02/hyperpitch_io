import React from "react";

const Footer = () => {
  const currentYear = new Date().getFullYear();
  const accentColor = "sky"; // Defined here for use in links

  return (
    <footer className="flex-shrink-0 bg-slate-50 py-5 px-4 sm:px-6 lg:px-8 border-t border-slate-200/70">
      <div className="text-slate-500 text-xs text-center">
        © {currentYear} Hyperpitch.io Inc. All rights reserved.
        <a
          className={`text-${accentColor}-600 hover:text-${accentColor}-800 transition-colors duration-200 ml-4 hover:underline`}
          href="/privacy"
        >
          Privacy
        </a>
         <a
          className={`text-${accentColor}-600 hover:text-${accentColor}-800 transition-colors duration-200 ml-4 hover:underline`}
          href="/terms"
        >
          Terms
        </a>
      </div>
    </footer>
  );
};

export default Footer;