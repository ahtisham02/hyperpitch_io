import React from "react";
import { Menu, Bell, ChevronDown } from "lucide-react";

const Navbar = ({ toggleSidebar }) => {
  const accentColor = "sky";
  const userInitials = "JD";
  const userName = "Jane Doe";

  return (
    <nav className={`sticky top-0 z-30 flex items-center justify-between h-[70px] 
                   bg-white/85 backdrop-blur-lg 
                   border-b border-slate-200/70 px-4 sm:px-6`}
    >
      <div className="flex items-center">
        <button
          onClick={toggleSidebar}
          className={`p-2.5 rounded-xl text-slate-500 hover:text-${accentColor}-600 hover:bg-${accentColor}-500/10 active:bg-${accentColor}-500/20 transition-all duration-200`}
          aria-label="Toggle Sidebar"
        >
          <Menu size={24} strokeWidth={2} />
        </button>
      </div>

      <div className="flex items-center space-x-3 sm:space-x-4">
        <button 
          className={`p-2.5 rounded-full text-slate-500 hover:text-${accentColor}-600 hover:bg-${accentColor}-500/10 active:bg-${accentColor}-500/20 relative transition-all duration-200`} 
          aria-label="Notifications"
        >
          <Bell size={22} strokeWidth={1.75} />
          <span className={`absolute top-1.5 right-1.5 block h-2.5 w-2.5 rounded-full bg-${accentColor}-500 ring-2 ring-white`} />
        </button>

        <button 
          className="flex items-center space-x-2.5 py-1.5 pl-1.5 pr-3 rounded-full hover:bg-slate-200/60 active:bg-slate-200/80 transition-all duration-200 group" 
          aria-label="User menu"
        >
          <div 
            className={`w-9 h-9 rounded-full bg-gradient-to-br from-${accentColor}-400 to-${accentColor}-600 text-white flex items-center justify-center text-xs font-semibold shadow-sm group-hover:shadow-md transition-shadow`}
          >
            {userInitials}
          </div>
          <span className="text-sm font-semibold text-slate-700 hidden sm:block group-hover:text-slate-900 transition-colors">
            {userName}
          </span>
          <ChevronDown size={18} className="text-slate-400 group-hover:text-slate-600 transition-colors" />
        </button>
      </div>
    </nav>
  );
};

export default Navbar;