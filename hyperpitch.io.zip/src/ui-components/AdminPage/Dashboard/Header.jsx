import React, { useState, useRef, useMemo, useEffect } from 'react';
import {
  DndContext,
  DragOverlay,
  PointerSensor,
  KeyboardSensor,
  useSensor,
  useSensors,
  closestCenter,
  useDraggable,
  useDroppable,
} from '@dnd-kit/core';
import {
  SortableContext,
  useSortable,
  arrayMove,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import img from "../../../assets/img/cards/672e98fa2d1ed0b7d1bf2adb_glass.png" 

function generateId(prefix = 'id') { return `${prefix}-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`; }

const textSizeOptions = [
  { label: 'Tiny', value: 'text-xs' },
  { label: 'Small', value: 'text-sm' },
  { label: 'Base', value: 'text-base' },
  { label: 'Large', value: 'text-lg' },
  { label: 'XL', value: 'text-xl' },
  { label: '2XL', value: 'text-2xl' },
  { label: '3XL', value: 'text-3xl' },
  { label: '4XL', value: 'text-4xl' },
];

const textAlignOptions = [
  { label: 'Left', value: 'text-left', icon: <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4"><path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25H12" /></svg> },
  { label: 'Center', value: 'text-center', icon: <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4"><path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-12.75 5.25h9" /></svg> },
  { label: 'Right', value: 'text-right', icon: <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4"><path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5M12 17.25h8.25" /></svg> }
];


function Header({ text = "Default Header Title", onUpdate, isSelected, sizeClass, textAlign, isPreviewMode }) { const handleBlur = (e) => { if (onUpdate && !isPreviewMode) onUpdate({ text: e.currentTarget.innerText }); }; return (<div className={`p-3 ${!isPreviewMode ? `rounded-md bg-slate-50 border ${isSelected ? 'border-sky-500 ring-1 ring-sky-400' : 'border-slate-200 hover:border-sky-200'}` : '' }`}><h1 className={`${sizeClass || 'text-xl'} ${textAlign || 'text-left'} font-semibold text-slate-700 ${!isPreviewMode ? 'focus:outline-none focus:ring-1 focus:ring-sky-300 focus:bg-white p-0.5 -m-0.5 rounded': ''}`} contentEditable={!isPreviewMode} suppressContentEditableWarning onBlur={handleBlur} dangerouslySetInnerHTML={{ __html: text }}></h1></div>); }
function TextBlock({ text = "Lorem ipsum dolor sit amet...", onUpdate, isSelected, sizeClass, textAlign, isPreviewMode }) { const handleBlur = (e) => { if (onUpdate && !isPreviewMode) onUpdate({ text: e.currentTarget.innerText }); }; return (<div className={`p-3 ${!isPreviewMode ? `rounded-md bg-slate-50 border ${isSelected ? 'border-sky-500 ring-1 ring-sky-400' : 'border-slate-200 hover:border-sky-200'}` : ''}`}><p className={`${sizeClass || 'text-sm'} ${textAlign || 'text-left'} text-slate-600 leading-relaxed ${!isPreviewMode ? 'focus:outline-none focus:ring-1 focus:ring-sky-300 focus:bg-white p-0.5 -m-0.5 rounded whitespace-pre-wrap' : 'whitespace-pre-wrap'}`} contentEditable={!isPreviewMode} suppressContentEditableWarning onBlur={handleBlur} dangerouslySetInnerHTML={{ __html: text }}></p></div>); }
function ImageElement({ src = "https://source.unsplash.com/random/500x250?art", alt = "Placeholder", width = "100%", height = "auto", isSelected, isPreviewMode }) { 
    const getStyleValue = (v) => (v === 'auto' || (typeof v === 'string' && v.endsWith('%'))) ? v : `${parseInt(v, 10) || 'auto'}px`; 
    return (
        <div className={`p-1.5 ${!isPreviewMode ? `rounded-md bg-slate-50 border ${isSelected ? 'border-sky-500 ring-1 ring-sky-400' : 'border-slate-200 hover:border-sky-200'}`:''}`}>
            <img 
                src={src} 
                alt={alt} 
                className={`max-w-full h-auto block mx-auto ${!isPreviewMode ? 'rounded':''}`} 
                style={{ width: getStyleValue(width), height: getStyleValue(height), minHeight: '40px', objectFit: 'contain' }} 
            />
        </div>
    ); 
}
function ButtonElement({ buttonText = "Click Me", link = "#", onUpdate, isSelected, sizeClass, textAlign, isPreviewMode }) { const handleTextBlur = (e) => { if (onUpdate && !isPreviewMode) onUpdate({ buttonText: e.currentTarget.innerText }); }; return (<div className={`p-1.5 ${textAlign || 'text-center'} ${!isPreviewMode && isSelected ? 'ring-1 ring-sky-400 rounded' : ''}`}><a href={isPreviewMode ? link : '#'} onClick={(e) => !isPreviewMode && e.preventDefault()} target={isPreviewMode ? "_blank" : "_self"} rel={isPreviewMode ? "noopener noreferrer" : ""} className={`inline-block px-4 py-2 bg-sky-500 text-white font-medium rounded shadow hover:bg-sky-600 ${sizeClass || 'text-xs'}`}><span contentEditable={!isPreviewMode} suppressContentEditableWarning onBlur={handleTextBlur} dangerouslySetInnerHTML={{ __html: buttonText }} className={`${!isPreviewMode ? 'focus:outline-none focus:ring-1 focus:ring-sky-200 p-0.5 -m-0.5 rounded':''}`}></span></a></div>); }
function Divider({ isSelected, isPreviewMode }) { return <div className={`py-2 px-1 ${!isPreviewMode && isSelected ? 'ring-1 ring-sky-400 rounded' : ''}`}><hr className="border-t border-slate-300 rounded-full" /></div>; }
function Spacer({ height = "20px", onUpdate, isSelected, isPreviewMode }) { return <div style={{ height }} className={`w-full ${!isPreviewMode && isSelected ? 'bg-sky-100/70 ring-1 ring-sky-400' : (!isPreviewMode ? 'bg-transparent': '')}`}></div>; }
function IconElement({ iconName = "FaStar", size = "28px", color = "currentColor", onUpdate, isSelected, isPreviewMode }) {
    const [IconComp, setIconComp] = useState(null);
    useEffect(() => {
        import('react-icons/fa').then(FaIcons => {
            setIconComp(() => FaIcons[iconName] || FaIcons.FaQuestionCircle);
        }).catch(err => {
            console.error("Failed to load react-icons/fa", err);
            import('react-icons/fa').then(FaIcons => setIconComp(() => FaIcons.FaQuestionCircle));
        });
    }, [iconName]);
    if (!IconComp) return <div className={`p-1.5 flex justify-center items-center ${!isPreviewMode && isSelected ? 'ring-1 ring-sky-400 rounded' : ''}`}>Loading icon...</div>;
    return <div className={`p-1.5 flex justify-center items-center ${!isPreviewMode && isSelected ? 'ring-1 ring-sky-400 rounded' : ''}`}><IconComp style={{ fontSize: size, color: color }} /></div>;
}
function GoogleMapsPlaceholder({ address = "1600 Amphitheatre Parkway, Mountain View, CA", zoom = 14, onUpdate, isSelected, isPreviewMode }) { return (<div className={`p-3 ${!isPreviewMode ? `rounded-md bg-slate-100 border ${isSelected ? 'border-sky-500 ring-1 ring-sky-400' : 'border-slate-300 hover:border-sky-300'}` : 'bg-slate-100 border border-slate-300'} aspect-video flex flex-col items-center justify-center text-center`}><svg className="h-10 w-10 text-slate-400 mb-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M17.657 16.657L13.414 20.9a2 2 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0zM15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg><p className="text-xs font-medium text-slate-600">{address}</p><p className="text-[10px] text-slate-500">Maps Placeholder (Zoom: {zoom})</p></div>); }
function InnerSectionComponentDisplay({ sectionData, onOpenStructureModal, onSelect, isSelected, onUpdateProps, onDelete, selectedItemId, isPreviewMode }) { const hasColumns = sectionData.columns && sectionData.columns.length > 0; const ownPath = sectionData.path; if (!hasColumns) { return (<div onClick={(e)=>{if(!isPreviewMode) {e.stopPropagation(); onSelect(sectionData.id, 'element', ownPath);}}} className={`p-3 min-h-[70px] flex flex-col items-center justify-center ${!isPreviewMode ? `rounded-md border-2 border-dashed ${isSelected ? 'border-sky-500 bg-sky-50/70' : 'border-slate-300 bg-slate-100/70 hover:border-sky-300'} cursor-pointer` : ''}`}><svg className="h-6 w-6 text-slate-400 mb-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6a2 2 0 012-2h12a2 2 0 012 2v12a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM10 12h4" /></svg>{!isPreviewMode && <button onClick={(e) => { e.stopPropagation(); onOpenStructureModal(ownPath, 'innerSection'); }} className="px-2 py-0.5 bg-sky-500 text-white text-[11px] font-medium rounded hover:bg-sky-600">Set Inner Structure</button>}</div>); } return (<div onClick={(e)=>{if(!isPreviewMode){e.stopPropagation(); onSelect(sectionData.id, 'element', ownPath);}}} className={`p-0.5 ${!isPreviewMode ? `border rounded-md ${isSelected ? 'border-sky-400 bg-sky-50/30' : 'border-slate-200'}`:''}`}><div className="flex flex-wrap -m-0.5">{sectionData.columns.map((col, colIdx) => (<ColumnComponent key={col.id} parentPath={ownPath} columnData={col} columnIndex={colIdx} onUpdateProps={onUpdateProps} onDelete={onDelete} onSelect={onSelect} selectedItemId={selectedItemId} onOpenStructureModal={onOpenStructureModal} isInner={true} isPreviewMode={isPreviewMode} />))}</div></div>); }

const ALL_ELEMENT_TYPES = { Header, TextBlock, ImageElement, ButtonElement, Divider, Spacer, IconElement, GoogleMapsPlaceholder, InnerSectionComponentDisplay };
const AVAILABLE_ELEMENTS_CONFIG = [ { id: 'header', name: 'Header', component: 'Header', defaultProps: { text: "Editable Header", sizeClass: '', textAlign: 'text-left' } }, { id: 'textBlock', name: 'Paragraph', component: 'TextBlock', defaultProps: { text: "Editable text.", sizeClass: '', textAlign: 'text-left' } }, { id: 'image', name: 'Image', component: 'ImageElement', defaultProps: { src: img , alt: "Placeholder Image", width: "100%", height: "auto" } }, { id: 'button', name: 'Button', component: 'ButtonElement', defaultProps: { buttonText: "Action Button", sizeClass: '', textAlign: 'text-center' } }, { id: 'divider', name: 'Divider', component: 'Divider', defaultProps: {} }, { id: 'spacer', name: 'Spacer', component: 'Spacer', defaultProps: { height: "25px" } }, { id: 'icon', name: 'Icon', component: 'IconElement', defaultProps: { iconName: "FaReact", size: "28px", color: "#61DAFB" } }, { id: 'googleMaps', name: 'Google Maps', component: 'GoogleMapsPlaceholder', defaultProps: { address: "New York, NY" } }, { id: 'innerSection', name: 'Inner Section', component: 'InnerSectionComponentDisplay', defaultProps: {}, isContainer: true, hasOwnColumns: true }, ];
const elementIcons = { header: ( <svg className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5"><path d="M7 20l4-16m2 16l4-16M6 9h14" /></svg> ), textBlock: ( <svg className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5"><path d="M4 6h16M4 12h16M4 18h7" /></svg> ), image: ( <svg className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5"><path d="M4 16l4.5-4.5a2 2 0 012.8 0L16 16m-2-2l1.5-1.5a2 2 0 012.8 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg> ), button: ( <svg className="h-7 w-7" viewBox="0 0 20 20" fill="currentColor"><path d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-11a1 1 0 10-2 0v2H7a1 1 0 100 2h2v2a1 1 0 102 0v-2h2a1 1 0 100-2h-2V7z" /></svg> ), divider: ( <svg className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5"><path d="M5 12h14" /></svg> ), spacer: (<svg className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5"><path strokeLinecap="round" strokeLinejoin="round" d="M8 7l4-4m0 0l4 4m-4-4v18" /></svg>), icon: (<svg className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5"><path strokeLinecap="round" strokeLinejoin="round" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.539 1.118l-3.975-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.196-1.539-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.783-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" /></svg>), googleMaps: (<svg className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5"><path strokeLinecap="round" strokeLinejoin="round" d="M17.657 16.657L13.414 20.9a2 2 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0zM15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>), innerSection: (<svg className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5"><path strokeLinecap="round" strokeLinejoin="round" d="M4 6a2 2 0 012-2h12a2 2 0 012 2v12a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM10 12h4" /></svg>), default: ( <svg className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5"><path d="M12 6v6m0 0v6m0-6h6m-6 0H6" /></svg> )};
const PREDEFINED_STRUCTURES = [ { name: '1 Col', id: '1col', layout: [{ width: '100%' }] }, { name: '2 Cols (50/50)', id: '2col5050', layout: [{ width: '50%' }, { width: '50%' }] }, { name: '2 Cols (33/67)', id: '2col3367', layout: [{ width: '33.33%' }, { width: '66.67%' }] }, { name: '3 Cols', id: '3col33', layout: [{ width: '33.33%' }, { width: '33.33%' }, { width: '33.33%' }] }, { name: '4 Cols', id: '4col25', layout: [{ width: '25%' }, { width: '25%' }, { width: '25%' }, { width: '25%' }] }, { name: '1/4 + 3/4', id: '1434', layout: [{ width: '25%' }, { width: '75%' }] }, ];

function getItemByPath(obj, pathString) { const path = pathString.replace(/\[(\w+)\]/g, '.$1').replace(/^\./, '').split('.'); let current = obj; for (const key of path) { if (current && typeof current === 'object' && (key in current || (Array.isArray(current) && !isNaN(parseInt(key))))) { current = current[key]; } else { return undefined; } } return current; }
function updateItemByPath(obj, pathString, newPropsOrUpdater) { const path = pathString.replace(/\[(\w+)\]/g, '.$1').replace(/^\./, '').split('.'); let current = obj; for (let i = 0; i < path.length - 1; i++) { if (current && typeof current === 'object' && (path[i] in current || (Array.isArray(current) && !isNaN(parseInt(path[i]))))) { current = current[path[i]]; } else { return false; } } const finalKey = path[path.length - 1]; if (current && typeof current === 'object' && (finalKey in current || (Array.isArray(current) && !isNaN(parseInt(finalKey))))) { if (typeof newPropsOrUpdater === 'function') { current[finalKey] = newPropsOrUpdater(current[finalKey]); } else { if (current[finalKey] && typeof current[finalKey] === 'object' && 'props' in current[finalKey]) { current[finalKey].props = { ...current[finalKey].props, ...newPropsOrUpdater }; } else if (current[finalKey] && typeof current[finalKey] === 'object') { current[finalKey] = { ...current[finalKey], ...newPropsOrUpdater }; } else { current[finalKey] = newPropsOrUpdater; } } return true; } return false; }
function deleteItemByPath(obj, pathString) { const path = pathString.replace(/\[(\w+)\]/g, '.$1').replace(/^\./, '').split('.'); let current = obj; for (let i = 0; i < path.length - 1; i++) { if (current && typeof current === 'object' && (path[i] in current || (Array.isArray(current) && !isNaN(parseInt(path[i]))))) { current = current[path[i]]; } else { return false; } } const finalKey = path[path.length - 1]; if (Array.isArray(current) && !isNaN(parseInt(finalKey))) { current.splice(parseInt(finalKey), 1); return true; } return false; }

function findItemAndPathRecursive(data, targetId, currentPathBase = '') {
    if (Array.isArray(data)) {
        for (let i = 0; i < data.length; i++) {
            const item = data[i];
            const itemPath = `${currentPathBase}[${i}]`;
            if (item.id === targetId) {
                return { item, path: itemPath };
            }
            if (item.columns) {
                const found = findItemAndPathRecursive(item.columns, targetId, `${itemPath}.columns`);
                if (found) return found;
            }
            if (item.elements) {
                const found = findItemAndPathRecursive(item.elements, targetId, `${itemPath}.elements`);
                if (found) return found;
            }
        }
    }
    return null;
}


function StructureSelectorModal({ isOpen, onClose, onSelectStructure, context }) { if (!isOpen) return null; return (<div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-3 print-hidden"><div className="bg-white p-5 md:p-6 rounded-lg shadow-xl max-w-xl w-full"><div className="flex justify-between items-center mb-5"><h3 className="text-lg font-semibold text-slate-700">Select Structure</h3><button onClick={onClose} className="text-slate-500 hover:text-slate-700 text-2xl">×</button></div><div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">{PREDEFINED_STRUCTURES.map(s => (<button key={s.id} onClick={() => { onSelectStructure(s.layout, context); onClose(); }} className="p-2.5 bg-slate-100 rounded hover:bg-sky-100 hover:ring-1 hover:ring-sky-400 transition-all flex flex-col items-center justify-center aspect-[4/3]"><div className="flex w-full h-7 mb-1.5 space-x-0.5 items-stretch">{s.layout.map((col, idx) => <div key={idx} className="bg-slate-400 rounded-sm" style={{ flexBasis: col.width }}></div>)}</div><span className="text-[10px] text-slate-600 text-center">{s.name}</span></button>))}</div></div></div>); }

function ElementPaletteItem({ config }) {
  const { attributes, listeners, setNodeRef, isDragging, transform } = useDraggable({
    id: `palette-${config.id}`,
    data: {
      type: 'paletteItem',
      config: config,
    },
  });

  const style = transform ? {
    transform: `translate3d(${transform.x}px, ${transform.y}px, 0)`,
    zIndex: 9999, 
    opacity: isDragging ? 0.8 : 1,
  } : {};

  if (isDragging) { 
    return (
      <div ref={setNodeRef} style={style} className="flex flex-col items-center justify-center p-1.5 text-center bg-sky-100 rounded-md shadow-lg ring-1 ring-sky-300 opacity-90">
        <div className="w-7 h-7 flex items-center justify-center text-sky-600 mb-0.5">{elementIcons[config.id] || elementIcons.default}</div>
        <span className="text-[10px] font-medium text-slate-700 leading-tight">{config.name}</span>
      </div>
    );
  }

  return (
    <div ref={setNodeRef} {...listeners} {...attributes} style={style}
      className={`flex flex-col items-center justify-center p-1.5 text-center bg-slate-100/80 rounded-md cursor-grab hover:bg-sky-100 hover:text-sky-700 transition-colors group shadow-sm`}>
      <div className="w-7 h-7 flex items-center justify-center text-sky-600 mb-0.5 group-hover:text-sky-700">{elementIcons[config.id] || elementIcons.default}</div>
      <span className="text-[10px] font-medium text-slate-700 group-hover:text-sky-700 leading-tight">{config.name}</span>
    </div>
  );
}
function PaletteItemDragOverlay({ config }) {
  return (
    <div className="flex flex-col items-center justify-center p-1.5 text-center bg-sky-50 rounded-md shadow-xl ring-1 ring-sky-400 opacity-95 cursor-grabbing">
      <div className="w-7 h-7 flex items-center justify-center text-sky-600 mb-0.5">{elementIcons[config.id] || elementIcons.default}</div>
      <span className="text-[10px] font-medium text-sky-700 leading-tight">{config.name}</span>
    </div>
  );
}


function ElementPalette({ onAddTopLevelSection }) {
  const [searchTerm, setSearchTerm] = useState('');
  const filteredElements = useMemo(() => AVAILABLE_ELEMENTS_CONFIG.filter(el => el.name.toLowerCase().includes(searchTerm.toLowerCase())), [searchTerm]);
  const addSectionConfig = { id: 'addSection', name: 'Add Section', component: '', isSpecial: true };

  return (
    <div className="w-60 bg-white p-3 border-r border-slate-200 shadow-sm flex-shrink-0 flex flex-col print-hidden">
      <input type="text" placeholder="Search Elements..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="w-full px-2 py-1 mb-2.5 border border-slate-300 rounded-md text-xs focus:ring-sky-500 focus:border-sky-500"/>
      <div className="grid grid-cols-2 gap-1.5 overflow-y-auto pr-0.5 -mr-1 flex-grow scrollbar-thin scrollbar-thumb-slate-300 scrollbar-track-slate-100">
        <div onClick={onAddTopLevelSection} className={`flex flex-col items-center justify-center p-1.5 text-center rounded-md cursor-pointer transition-colors group bg-sky-100 hover:bg-sky-200 border border-sky-300 shadow-sm`}>
            <div className="w-7 h-7 flex items-center justify-center text-sky-600 mb-0.5 group-hover:text-sky-700"><svg className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5"><path d="M12 4v16m8-8H4" /></svg></div>
            <span className="text-[10px] font-medium text-slate-700 group-hover:text-sky-700 leading-tight">{addSectionConfig.name}</span>
        </div>
        {filteredElements.map((elConf) => <ElementPaletteItem key={elConf.id} config={elConf} />)}
      </div>
    </div>
  );
}

function DraggableCanvasElement({ elementData, onUpdateProps, onDelete, onSelect, isSelected, onOpenStructureModal, parentColumnId, isPreviewMode }) {
  const config = AVAILABLE_ELEMENTS_CONFIG.find(c => c.id === elementData.type);
  if (!config) return null;

  const ComponentToRender = ALL_ELEMENT_TYPES[config.component];
  
  const {
    attributes, listeners, setNodeRef, transform, transition, isDragging
  } = useSortable({
    id: elementData.id,
    data: {
      type: 'canvasElement',
      elementId: elementData.id,
      parentColumnId: parentColumnId,
      elementType: elementData.type,
      elementData: elementData
    },
    disabled: isPreviewMode,
  });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging && !isPreviewMode ? 0.4 : 1,
    zIndex: isDragging && !isPreviewMode ? 10 : 'auto',
  };

  const handleUpdate = (newProps) => { if(!isPreviewMode) onUpdateProps(elementData.path, newProps); };
  const handleClick = (e) => { if(!isPreviewMode) {e.stopPropagation(); onSelect(elementData.id, 'element', elementData.path); }};

  return (
    <div ref={setNodeRef} style={style} onClick={handleClick}
         className={`relative ${!isPreviewMode ? `group transition-all duration-150 ease-in-out ${isDragging ? 'bg-sky-50/70 shadow-lg ring-1 ring-sky-300 scale-[1.005]' : ''} ${isSelected ? 'outline outline-1 outline-sky-500 outline-offset-1' : 'hover:outline hover:outline-[0.5px] hover:outline-sky-300/70'}` : ''}`}>
      {!isPreviewMode && (
        <div {...attributes} {...listeners} title="Drag element" 
            className="absolute top-1/2 -left-2.5 transform -translate-y-1/2 p-1 cursor-grab bg-slate-100 hover:bg-sky-500 text-slate-500 hover:text-white rounded-full shadow border border-slate-300 hover:border-sky-500 opacity-0 group-hover:opacity-100 group-focus-within:opacity-100 z-10 print-hidden">
            <svg className="h-3.5 w-3.5" viewBox="0 0 20 20" fill="currentColor"><path d="M7 4a1 1 0 011-1h4a1 1 0 110 2H8a1 1 0 01-1-1zm1 3a1 1 0 000 2h4a1 1 0 100-2H8zm-1 5a1 1 0 011-1h4a1 1 0 110 2H8a1 1 0 01-1-1z" /></svg>
        </div>
      )}
      <div className={!isPreviewMode && isSelected ? "" : (isPreviewMode ? "" : "pointer-events-none")}> 
        <ComponentToRender {...elementData.props} sectionData={elementData} onUpdate={handleUpdate} elementId={elementData.id} isSelected={!isPreviewMode && isSelected} onOpenStructureModal={onOpenStructureModal} onSelect={onSelect} onDelete={onDelete} onUpdateProps={onUpdateProps} selectedItemId={!isPreviewMode && isSelected ? elementData.id : null} isPreviewMode={isPreviewMode}/>
      </div>
      {!isPreviewMode && isSelected && (
        <button onClick={(e) => { e.stopPropagation(); onDelete(elementData.path); }} title="Delete"
                className="absolute top-0.5 right-0.5 p-0.5 bg-red-500 text-white rounded-full hover:bg-red-600 hover:scale-105 transition-all text-xs w-3.5 h-3.5 flex items-center justify-center shadow z-20 print-hidden">
          <svg className="h-2 w-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="3"><path d="M6 18L18 6M6 6l12 12" /></svg>
        </button>
      )}
    </div>
  );
}

function ColumnComponent({ parentPath, columnData, columnIndex, onUpdateProps, onDelete, onSelect, selectedItemId, onOpenStructureModal, isInner = false, isPreviewMode }) {
  const columnPath = `${parentPath}.${isInner ? 'columns' : 'columns'}[${columnIndex}]`;
  const isSelected = selectedItemId === columnData.id;
  const handleClick = (e) => { if(!isPreviewMode) {e.stopPropagation(); onSelect(columnData.id, 'column', columnPath);} };

  const { setNodeRef: setDroppableRef, isOver } = useDroppable({
    id: `col-${columnData.id}`, 
    data: {
      type: 'column',
      columnId: columnData.id,
      path: columnPath, 
      accepts: ['paletteItem', 'canvasElement'] 
    },
    disabled: isPreviewMode,
  });

  const elementIds = useMemo(() => columnData.elements.map(el => el.id), [columnData.elements]);

  return (
    <div onClick={handleClick} style={{ flexBasis: columnData.props.width || '100%' }}
         className={`p-1 md:p-1.5 flex-shrink-0 ${!isPreviewMode && isSelected ? 'outline outline-1 outline-dashed outline-blue-400 bg-blue-50/20' : (!isPreviewMode ? 'hover:outline hover:outline-[0.5px] hover:outline-blue-200/50' : '')}`}>
      <SortableContext items={elementIds} strategy={verticalListSortingStrategy} disabled={isPreviewMode}>
        <div ref={setDroppableRef}
             className={`min-h-[60px] p-1 ${!isPreviewMode ? `rounded-md transition-colors ${isOver ? 'bg-sky-100 ring-1 ring-sky-300' : 'bg-slate-50/30'} ${columnData.elements.length === 0 && !isOver ? 'border border-dashed border-slate-300 flex items-center justify-center text-slate-400 text-[10px]' : ''}` : '' }`}>
          {!isPreviewMode && columnData.elements.length === 0 && !isOver ? 'Drop here' : null}
          {columnData.elements.map((el, elIdx) => (
            <DraggableCanvasElement 
              key={el.id} 
              elementData={{...el, path: `${columnPath}.elements[${elIdx}]`}} 
              onUpdateProps={onUpdateProps} 
              onDelete={onDelete} 
              onSelect={onSelect} 
              isSelected={selectedItemId === el.id} 
              onOpenStructureModal={onOpenStructureModal}
              parentColumnId={columnData.id} 
              isPreviewMode={isPreviewMode}
            />
          ))}
        </div>
      </SortableContext>
    </div>
  );
}

function SectionComponent({ sectionData, sectionIndex, onUpdateProps, onDelete, onSelect, selectedItemId, onOpenStructureModal, isPreviewMode }) {
  const sectionPath = `sections[${sectionIndex}]`; 
  const isSelected = selectedItemId === sectionData.id;
  const handleClick = (e) => { if(!isPreviewMode) onSelect(sectionData.id, 'section', sectionPath);};

  const {
    attributes, listeners, setNodeRef, transform, transition, isDragging
  } = useSortable({
    id: sectionData.id,
    data: {
      type: 'section',
      sectionId: sectionData.id,
      path: sectionPath, 
      sectionData: sectionData
    },
    disabled: isPreviewMode,
  });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging && !isPreviewMode ? 0.7 : 1,
    zIndex: isDragging && !isPreviewMode ? 20 : 'auto',
  };

  return (
    <div ref={setNodeRef} style={style} onClick={handleClick}
         className={`relative p-1 ${!isPreviewMode ? `group transition-all duration-150 ease-in-out ${isDragging ? 'bg-sky-50/70 shadow-lg ring-1 ring-sky-300' : 'bg-white shadow-sm hover:shadow-md'} ${isSelected ? 'outline outline-1 outline-green-500' : ''}` : 'bg-white'}`}>
      {!isPreviewMode && (
        <div {...attributes} {...listeners} title="Drag section" 
            className="absolute top-0.5 left-0.5 p-0.5 cursor-grab bg-slate-200 hover:bg-green-500 text-slate-600 hover:text-white rounded shadow opacity-5 group-hover:opacity-100 print-hidden z-10">
            <svg className="h-3.5 w-3.5" viewBox="0 0 20 20" fill="currentColor"><path d="M5 8a1 1 0 000 2h10a1 1 0 100-2H5zm0 5a1 1 0 000 2h10a1 1 0 100-2H5z" /></svg>
        </div>
      )}
      {!isPreviewMode && isSelected && (
        <button onClick={(e) => { e.stopPropagation(); onDelete(sectionPath); }} title="Delete section"
                className="absolute top-0.5 right-0.5 p-0.5 bg-red-500 text-white rounded-full hover:bg-red-600 transition-all text-xs w-3.5 h-3.5 flex items-center justify-center shadow z-20 print-hidden">
          <svg className="h-2 w-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="3"><path d="M6 18L18 6M6 6l12 12" /></svg>
        </button>
      )}
      <div className="flex flex-wrap -m-0.5">
        {sectionData.columns.map((col, colIdx) => (
          <ColumnComponent 
            key={col.id} 
            parentPath={sectionPath} 
            columnData={col} 
            columnIndex={colIdx} 
            onUpdateProps={onUpdateProps} 
            onDelete={onDelete} 
            onSelect={onSelect} 
            selectedItemId={selectedItemId} 
            onOpenStructureModal={onOpenStructureModal}
            isPreviewMode={isPreviewMode}
          />
        ))}
      </div>
    </div>
  );
}

function PropertiesPanel({ selectedItemData, onUpdateSelectedProps, onClosePanel }) { 
  const fileInputRef = useRef(null);
  if (!selectedItemData) return (<div className="w-64 bg-white p-3 border-l border-slate-200 shadow-sm flex-shrink-0 print-hidden"><h2 className="text-base font-semibold mb-2 text-slate-700">Properties</h2><p className="text-slate-500 text-xs">Select an item on the canvas.</p></div>); 
  const { id, type, path, props } = selectedItemData; 
  const handlePropChange = (propName, value) => onUpdateSelectedProps(path, { [propName]: value }); 
  
  const elementType = props.elementType || (type === 'element' ? props.type : null);

  const handleImageFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        handlePropChange('src', reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="w-64 bg-white p-3 border-l border-slate-200 shadow-sm flex-shrink-0 flex flex-col print-hidden">
      <div className="flex justify-between items-center mb-2">
        <h2 className="text-base font-semibold text-slate-700 capitalize">{type === 'element' ? elementType : type}</h2>
        <button onClick={onClosePanel} className="text-slate-400 hover:text-slate-600 text-xl">×</button>
      </div>
      <div className="overflow-y-auto flex-grow scrollbar-thin scrollbar-thumb-slate-300 scrollbar-track-slate-100 text-xs space-y-2">
        {Object.entries(props || {}).map(([key, value]) => { 
          if (key === 'elementType' || key === 'sizeClass' || key === 'textAlign' || (elementType === 'image' && (key === 'src' || key === 'width' || key === 'height' || key === 'alt'))) return null; 
          if (typeof value === 'string' || typeof value === 'number') { 
            return (
              <div key={key}>
                <label className="block text-[10px] font-medium text-slate-600 mb-0.5 capitalize">{key.replace(/([A-Z])/g, ' $1')}</label>
                <input 
                  type={typeof value === 'number' ? 'number' : 'text'} 
                  value={value} 
                  onChange={(e) => handlePropChange(key, typeof value === 'number' ? parseFloat(e.target.value) : e.target.value)} 
                  className="w-full p-1 border border-slate-300 rounded-md text-[11px] focus:ring-sky-500 focus:border-sky-500"/>
              </div>
            ); 
          } 
          return null; 
        })} 
        {(elementType === 'header' || elementType === 'textBlock' || elementType === 'button') && (
          <>
            <div>
              <label className="block text-[10px] font-medium text-slate-600 mb-0.5">Text Size</label>
              <select
                value={props.sizeClass || ''}
                onChange={(e) => handlePropChange('sizeClass', e.target.value)}
                className="w-full p-1 border border-slate-300 rounded-md text-[11px] focus:ring-sky-500 focus:border-sky-500"
              >
                <option value="">Default</option>
                {textSizeOptions.map(opt => (
                  <option key={opt.value} value={opt.value}>{opt.label}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-[10px] font-medium text-slate-600 mb-0.5">Text Align</label>
              <div className="flex space-x-1">
                {textAlignOptions.map(opt => (
                  <button
                    key={opt.value}
                    title={opt.label}
                    onClick={() => handlePropChange('textAlign', opt.value)}
                    className={`flex-1 p-1 flex items-center justify-center rounded text-[10px] border ${props.textAlign === opt.value ? 'bg-sky-500 text-white border-sky-500' : 'bg-slate-100 hover:bg-slate-200 border-slate-300 text-slate-600'}`}
                  >
                    {opt.icon}
                  </button>
                ))}
              </div>
            </div>
          </>
        )}
        {elementType === 'image' && (
          <>
            <div>
              <label className="block text-[10px] font-medium text-slate-600 mb-0.5">Image Source</label>
              <button 
                onClick={() => fileInputRef.current?.click()} 
                className="w-full px-1.5 py-0.5 bg-sky-500 text-white rounded hover:bg-sky-600 text-[11px] mb-0.5"
              >
                Change Image
              </button>
              <input 
                type="file" 
                accept="image/*" 
                ref={fileInputRef} 
                className="hidden" 
                onChange={handleImageFileChange}
              />
              <input 
                type="text" 
                value={props.src || ''} 
                onChange={(e) => handlePropChange('src', e.target.value)} 
                placeholder="Or paste image URL"
                className="w-full p-1 border border-slate-300 rounded-md text-[11px] focus:ring-sky-500 focus:border-sky-500"/>
            </div>
            <div>
              <label className="block text-[10px] font-medium text-slate-600 mb-0.5">Width</label>
              <input 
                type="text" 
                value={props.width || ''} 
                onChange={(e) => handlePropChange('width', e.target.value)} 
                placeholder="e.g., 100% or 250px"
                className="w-full p-1 border border-slate-300 rounded-md text-[11px] focus:ring-sky-500 focus:border-sky-500"/>
            </div>
            <div>
              <label className="block text-[10px] font-medium text-slate-600 mb-0.5">Height</label>
              <input 
                type="text" 
                value={props.height || ''} 
                onChange={(e) => handlePropChange('height', e.target.value)} 
                placeholder="e.g., auto or 150px"
                className="w-full p-1 border border-slate-300 rounded-md text-[11px] focus:ring-sky-500 focus:border-sky-500"/>
            </div>
            <div>
              <label className="block text-[10px] font-medium text-slate-600 mb-0.5">Alt Text</label>
              <input 
                type="text" 
                value={props.alt || ''} 
                onChange={(e) => handlePropChange('alt', e.target.value)} 
                placeholder="Image description"
                className="w-full p-1 border border-slate-300 rounded-md text-[11px] focus:ring-sky-500 focus:border-sky-500"/>
            </div>
          </>
        )}
        {elementType === 'icon' && (
          <div>
            <label className="block text-[10px] font-medium text-slate-600 mb-0.5">Icon Name (e.g., FaStar)</label>
            <input type="text" value={props.iconName || ''} onChange={(e) => handlePropChange('iconName', e.target.value)} className="w-full p-1 border rounded-md text-[11px]"/>
          </div>
        )} 
        <details className="text-[11px]">
          <summary className="cursor-pointer text-slate-500">Raw Props</summary>
          <pre className="bg-slate-100 p-1.5 rounded overflow-x-auto mt-0.5 text-[10px]">{JSON.stringify(props, null, 2)}</pre>
        </details>
      </div>
    </div>
  ); 
}

function CanvasArea({ pageLayout, onUpdateProps, onDelete, onSelect, selectedItemId, onOpenStructureModal, isPreviewMode }) {
  const { setNodeRef: setPageDroppableRef, isOver: isPageOver } = useDroppable({
    id: 'page-sections-droppable', 
    data: {
      type: 'page',
      accepts: ['paletteItem', 'section'] 
    },
    disabled: isPreviewMode,
  });

  const sectionIds = useMemo(() => pageLayout.map(sec => sec.id), [pageLayout]);

  return (
    <div className={`flex-1 overflow-y-auto scrollbar-thin scrollbar-thumb-slate-300 scrollbar-track-slate-200/50 ${isPreviewMode ? 'p-0 bg-white' : 'p-3 md:p-4 bg-slate-100/70'}`}>
      <div className={`${isPreviewMode ? '' : 'max-w-4xl mx-auto'}`}>
        <SortableContext items={sectionIds} strategy={verticalListSortingStrategy} disabled={isPreviewMode}>
          <div ref={setPageDroppableRef}
               className={`min-h-[calc(100vh-theme(space.12))] ${isPreviewMode ? '' : `p-0.5 sm:p-1 transition-all duration-200 ease-in-out canvas-render-area ${isPageOver ? 'bg-sky-100/60 ring-1 ring-sky-300' : ''} ${pageLayout.length === 0 && !isPageOver ? 'border-2 border-dashed border-slate-300/80' : ''}`}`}>
            {pageLayout.map((sec, idx) => (
              <SectionComponent 
                key={sec.id} 
                sectionData={sec} 
                sectionIndex={idx} 
                onUpdateProps={onUpdateProps} 
                onDelete={onDelete} 
                onSelect={onSelect} 
                selectedItemId={selectedItemId} 
                onOpenStructureModal={onOpenStructureModal}
                isPreviewMode={isPreviewMode}
              />
            ))}
            {!isPreviewMode && pageLayout.length === 0 && !isPageOver && (
              <div className="flex flex-col items-center justify-center h-full text-center py-16 select-none">
                <svg className="h-14 w-14 text-slate-400/80 mb-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1"><path d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>
                <p className="text-slate-500/90 text-sm mt-1">Drag an element here or use "Add Section" from the palette.</p>
              </div>
            )}
          </div>
        </SortableContext>
      </div>
    </div>
  );
}

function PagePreviewRenderer({ pageLayout, onUpdateProps, onDelete, onSelect, onOpenStructureModal }) {
  return (
    <div className="flex-1 overflow-y-auto bg-white p-4 scrollbar-thin scrollbar-thumb-slate-300 scrollbar-track-slate-100">
      <div className="max-w-4xl mx-auto">
        {pageLayout.map((sec, idx) => (
          <SectionComponent 
            key={sec.id} 
            sectionData={sec} 
            sectionIndex={idx} 
            onUpdateProps={onUpdateProps} 
            onDelete={onDelete} 
            onSelect={onSelect} 
            selectedItemId={null}
            onOpenStructureModal={onOpenStructureModal}
            isPreviewMode={true}
          />
        ))}
      </div>
    </div>
  );
}


function PageActions({ onSave, onTogglePreview, isPreviewMode }) { 
  return (
    <div className={`bg-white p-2 border-b border-slate-200 shadow-sm ${isPreviewMode ? 'print-styles-preview-actions' : 'print-hidden'}`}>
      <div className="max-w-6xl mx-auto flex justify-end items-center space-x-2">
        <button 
          onClick={onTogglePreview} 
          className="px-2.5 py-1 text-[11px] font-medium text-white bg-indigo-500 rounded hover:bg-indigo-600"
        >
          {isPreviewMode ? 'Close Preview' : 'View Page'}
        </button>
        {!isPreviewMode && (
          <button 
            onClick={onSave} 
            className="px-2.5 py-1 text-[11px] font-medium text-white bg-sky-500 rounded hover:bg-sky-600"
          >
            Save
          </button>
        )}
      </div>
    </div>
  ); 
}

export default function ElementBuilderPage() {
  const [pageLayout, setPageLayout] = useState([]);
  const [isStructureModalOpen, setIsStructureModalOpen] = useState(false);
  const [structureModalContext, setStructureModalContext] = useState({ path: null, elementType: null });
  const [selectedItem, setSelectedItem] = useState(null);
  const [activeDragItem, setActiveDragItem] = useState(null); 
  const [isPreviewMode, setIsPreviewMode] = useState(false);

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor)
  );

  const handleOpenStructureModal = (contextPath, forElementType = null) => { 
    setStructureModalContext({ path: contextPath, elementType: forElementType }); 
    setIsStructureModalOpen(true); 
  };
  const handleSetStructure = (columnLayouts, context) => {
    const newColumns = columnLayouts.map(layout => ({ id: generateId('col'), type: 'column', props: { width: layout.width }, elements: [] }));
    setPageLayout(prevLayout => {
        const newLayout = JSON.parse(JSON.stringify(prevLayout)); 
        if (context.path === null && context.elementType === 'section') {
            const newSection = { id: generateId('section'), type: 'section', props: {}, columns: newColumns };
            newLayout.push(newSection);
        } else if (context.path && context.elementType === 'innerSection') {
            const itemToUpdate = getItemByPath({ sections: newLayout }, context.path);
            if (itemToUpdate && itemToUpdate.type === 'innerSection') {
                itemToUpdate.columns = newColumns;
            }
        }
        return newLayout;
    });
  };

  const handleSelect = (id, type, path) => {
    if (isPreviewMode) return;
    const itemData = getItemByPath({ sections: pageLayout }, path);
    if (itemData) {
      let propsToSet = itemData.props;
      if (type === 'element') propsToSet = { ...itemData.props, elementType: itemData.type }; 
      setSelectedItem({ id, type, path, props: propsToSet });
    } else {
      setSelectedItem(null);
    }
  };

  const handleUpdateProps = (itemPath, newProps) => {
    setPageLayout(prevLayout => {
        const newLayout = JSON.parse(JSON.stringify(prevLayout));
        if (updateItemByPath({ sections: newLayout }, itemPath, newProps)) {
            if (selectedItem && selectedItem.path === itemPath) {
                const updatedItem = getItemByPath({ sections: newLayout }, itemPath);
                if (updatedItem) {
                    let propsToSet = updatedItem.props;
                    if (selectedItem.type === 'element') propsToSet = { ...updatedItem.props, elementType: updatedItem.type };
                    setSelectedItem(prev => ({ ...prev, props: propsToSet }));
                }
            }
            return newLayout;
        }
        return prevLayout; 
    });
  };

  const handleDelete = (itemPath) => {
    if (isPreviewMode) return;
    setPageLayout(prevLayout => {
        const newLayout = JSON.parse(JSON.stringify(prevLayout));
        if (deleteItemByPath({ sections: newLayout }, itemPath)) {
            if (selectedItem && selectedItem.path === itemPath) setSelectedItem(null);
            return newLayout;
        }
        return prevLayout;
    });
  };

  const findColumn = (layout, columnId) => {
    for (const section of layout) {
      if (section.columns) {
        for (const col of section.columns) {
          if (col.id === columnId) return col;
          if (col.elements) { 
            for (const el of col.elements) {
              if (el.type === 'innerSection' && el.columns) {
                const innerCol = el.columns.find(ic => ic.id === columnId);
                if (innerCol) return innerCol;
              }
            }
          }
        }
      }
    }
    return null;
  };

  const handleDragStart = (event) => {
    if (isPreviewMode) return;
    setActiveDragItem(event.active);
  };

  const handleDragEnd = (event) => {
    if (isPreviewMode) return;
    const { active, over } = event;
    setActiveDragItem(null);

    if (!over) return;
    if (active.id === over.id && active.data.current?.type !== 'paletteItem') return;

    const activeType = active.data.current?.type;
    const activeId = active.id;
    
    const overId = over.id;
    const overDataType = over.data.current?.type;
    const overColumnId = overDataType === 'column' ? over.data.current?.columnId : (overDataType === 'canvasElement' ? over.data.current?.parentColumnId : null);

    setPageLayout(prevLayout => {
      let newLayout = JSON.parse(JSON.stringify(prevLayout));

      if (activeType === 'paletteItem') {
        const config = active.data.current.config;
        const newElement = {
          id: generateId(config.id),
          type: config.id,
          props: { ...config.defaultProps } 
        };
        if (config.hasOwnColumns) newElement.columns = [];

        if (overDataType === 'column' || (overDataType === 'canvasElement' && overColumnId)) {
            const targetColId = overDataType === 'column' ? over.id.replace('col-', '') : overColumnId;
            const targetColumn = findColumn(newLayout, targetColId);
            if (targetColumn) {
                if (!targetColumn.elements) targetColumn.elements = [];
                let insertAtIndex = targetColumn.elements.length;
                if (overDataType === 'canvasElement') {
                    const overElementIndex = targetColumn.elements.findIndex(el => el.id === over.id);
                    if (overElementIndex !== -1) insertAtIndex = overElementIndex;
                }
                targetColumn.elements.splice(insertAtIndex, 0, newElement);
            } else { console.warn("Target column for palette drop not found:", targetColId); return prevLayout; }
        }
        else if (overDataType === 'page' || overDataType === 'section') {
          if (newElement.type === 'innerSection') { alert("Inner Sections must be placed inside a column."); return prevLayout; }
          const newSection = { id: generateId('section'), type: 'section', props: {}, columns: [{ id: generateId('col'), type: 'column', props: { width: '100%' }, elements: [newElement] }] };
          
          let sectionInsertIndex = newLayout.length;
          if(overDataType === 'section'){
            const targetSectionIndex = newLayout.findIndex(s => s.id === over.id);
            if(targetSectionIndex !== -1) sectionInsertIndex = targetSectionIndex + 1; 
          }
          newLayout.splice(sectionInsertIndex, 0, newSection);
        } else { console.warn("Invalid drop target for palette item:", over); return prevLayout; }
      }
      else if (activeType === 'section' && (overDataType === 'section' || overDataType === 'page')) {
        const activeSectionIndex = newLayout.findIndex(s => s.id === activeId);
        const overSectionIndex = overDataType === 'page' ? newLayout.length -1 : newLayout.findIndex(s => s.id === overId);

        if (activeSectionIndex !== -1 && overSectionIndex !== -1) {
          newLayout = arrayMove(newLayout, activeSectionIndex, overSectionIndex);
        } else { console.warn("Section reorder failed: indices not found"); return prevLayout; }
      }
      else if (activeType === 'canvasElement') {
        const sourceColumnId = active.data.current.parentColumnId;
        const sourceColumn = findColumn(newLayout, sourceColumnId);
        
        let targetColumn;
        let targetElementIndex = 0;

        if (overDataType === 'column') { 
            targetColumn = findColumn(newLayout, over.id.replace('col-', ''));
            if (targetColumn) targetElementIndex = targetColumn.elements.length;
        } else if (overDataType === 'canvasElement') { 
            targetColumn = findColumn(newLayout, over.data.current.parentColumnId);
            if (targetColumn) {
                const overElIdx = targetColumn.elements.findIndex(el => el.id === over.id);
                if (overElIdx !== -1) targetElementIndex = overElIdx; 
                else targetElementIndex = targetColumn.elements.length; 
            }
        } else { console.warn("Invalid drop target for canvas element:", over); return prevLayout; }

        if (sourceColumn && targetColumn) {
          const activeElementIndex = sourceColumn.elements.findIndex(el => el.id === activeId);
          if (activeElementIndex !== -1) {
            const [movedElement] = sourceColumn.elements.splice(activeElementIndex, 1);
            if (!targetColumn.elements) targetColumn.elements = [];
            targetColumn.elements.splice(targetElementIndex, 0, movedElement);
          } else { console.warn("Active element not found in source column"); return prevLayout; }
        } else { console.warn("Source or target column not found for element move"); return prevLayout; }
      } else {
        console.log("Unhandled drag case:", { activeType, overDataType, active, over });
        return prevLayout;
      }

      if (selectedItem) {
        const found = findItemAndPathRecursive(newLayout, selectedItem.id, 'sections');
        if (found) {
            const { item: newItemData, path: newPath } = found;
            let propsToSet = newItemData.props;
            if (selectedItem.type === 'element') propsToSet = { ...newItemData.props, elementType: newItemData.type };
            setSelectedItem({ id: selectedItem.id, type: selectedItem.type, path: newPath, props: propsToSet });
        } else {
            setSelectedItem(null); 
        }
      }
      return newLayout;
    });
  };

  const togglePreviewMode = () => {
    setIsPreviewMode(prev => !prev);
    if(!isPreviewMode) setSelectedItem(null); 
  };

  if (isPreviewMode) {
    return (
      <div className="flex flex-col h-screen max-h-screen font-sans bg-white overflow-hidden">
        <PageActions onTogglePreview={togglePreviewMode} isPreviewMode={isPreviewMode} />
        <PagePreviewRenderer 
            pageLayout={pageLayout} 
            onUpdateProps={handleUpdateProps}
            onDelete={handleDelete}
            onSelect={handleSelect}
            onOpenStructureModal={handleOpenStructureModal}
        />
      </div>
    );
  }

  return (
    <DndContext 
      sensors={sensors} 
      collisionDetection={closestCenter} 
      onDragStart={handleDragStart}
      onDragEnd={handleDragEnd}
      disabled={isPreviewMode}
    >
      <div className="flex flex-col h-screen max-h-screen font-sans bg-slate-50 overflow-hidden">
        <PageActions onSave={() => console.log(JSON.stringify(pageLayout))} onTogglePreview={togglePreviewMode} isPreviewMode={isPreviewMode} />
        <div className={`flex flex-row flex-grow overflow-hidden`}>
          {selectedItem ? (
            <PropertiesPanel selectedItemData={selectedItem} onUpdateSelectedProps={handleUpdateProps} onClosePanel={() => setSelectedItem(null)} />
          ) : (
            <ElementPalette 
              onAddTopLevelSection={() => handleOpenStructureModal(null, 'section')} 
            />
          )}
          <CanvasArea 
            pageLayout={pageLayout} 
            onUpdateProps={handleUpdateProps} 
            onDelete={handleDelete} 
            onSelect={handleSelect} 
            selectedItemId={selectedItem ? selectedItem.id : null} 
            onOpenStructureModal={handleOpenStructureModal}
            isPreviewMode={isPreviewMode}
          />
        </div>
      </div>
      <DragOverlay dropAnimation={null}>
            {activeDragItem ? (
            activeDragItem.data.current?.type === 'paletteItem' ? (
                <PaletteItemDragOverlay config={activeDragItem.data.current.config} />
            ) : activeDragItem.data.current?.type === 'canvasElement' ? (
                <div className="p-2 bg-sky-100 border border-sky-300 rounded shadow-lg opacity-80">
                Moving: {activeDragItem.data.current?.elementType || 'Element'}
                </div>
            ) : activeDragItem.data.current?.type === 'section' ? (
                <div className="p-2 bg-green-100 border border-green-300 rounded shadow-lg opacity-80">
                Moving Section
                </div>
            ) : null
            ) : null}
        </DragOverlay>
        <StructureSelectorModal 
            isOpen={isStructureModalOpen} 
            onClose={() => setIsStructureModalOpen(false)} 
            onSelectStructure={handleSetStructure} 
            context={structureModalContext}
        />
    </DndContext>
  );
}